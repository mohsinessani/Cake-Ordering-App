from tkinter import *
from tkinter import messagebox
window=Tk()
window.geometry("500x500")
window.config(background="cyan")  #window colour
label1 = Label(window, text="User Information", fg="blue", bg="yellow", relief="solid", width=20,
               font=("arial", 19, "bold"))
label1.place(x=90, y=53)


 # Textbox for Label2

e = Entry(window, width=20, font=("arial", 17, "italic"))
e.grid(row=2, column=2)

# labelhead=Label(window,text="ENTER YOUR INFORMATION HERE",fg="black",bg="#FFEBCD",font=("arial",20,"bold"))
# labelhead.place(x=200,y=40)

 # Label 2 Reg Form

label2 = Label(window, text="Enter Your Name", fg="blue", relief="solid", width=15, font=("arial", 17, "italic"))
label2.place(x=20, y=120)
e.place(x=250, y=130)

    #Textbox for Label3
ent = Entry(window, width=20, font=("arial", 17, "italic"))


# e2=Entry(window,width=30,font=("arial", 15, "bold"))  #Text BOX
# e2.grid(row=1,column=1)
# lab2=Label(window, text="MOBILE NUMBER: ", fg="BLACK", bg="#FFEBCD", font=("arial", 15, "bold"))
# lab2.place(x=50,y=200)
# e2.place(x=250,y=200)
#


#edg = new place(x=100,y=200
#Labell1=new Label (x=100,y=100)
#label3=place(

# Label 2 Reg Form

label3 = Label(window, text="Enter Your Number",fg="blue", relief="solid",width=15, font=("arial", 17, "italic"))
label3.place(x=20, y=170)
ent.place(x=250, y=170)




dataBackup = []
def submitbutton():
    num = ent.get()
    value = len(num)
    if value != 10:
        messagebox.showerror("Incorrect Mobile Number","Enter Correct Mobile Number")
    elif num.isdigit():
        file = open("dataa.txt", "r")
        fileData = file.read()
        if num in fileData:
            messagebox.showerror("Incorrect","Data is Already Exsits")
        else:

            print("Name has been inserted")
            namedata=e.get()
            print(namedata)
            print("Mobile number has been inserted")
            mobiledata=ent.get()
            print(mobiledata)
            file=open("dataa.txt","a")
            file.write("\nName: \t")
            file.write(namedata)
            file.write("\nMobile Number: \t")
            file.write(mobiledata)
            dataBackup.insert(0, [namedata, mobiledata])
            messagebox.showinfo("Submitted", "Your data has submitted")
    else:
        messagebox.showerror("Incorrect", "Enter only numbers")

but1=Button(window,text=" Submit ",bg="lightpink", command=submitbutton,width=12,relief="solid",font=("arial",16,"italic"))
but1.place(x=155, y=220)


 # Label 3 View  Form

label4 = Label(window, text="View User Data", fg="blue", relief="solid", width=15, font=("arial", 17, "italic"))
label4.place(x=20, y=280)


e3=Text(window,height=5,width=50,font=("arial",13,"bold"))
e3.place(x=50,y=320)

def checkbutton():
        global dataBackup
        namedata = e.get()
        mobiledata =ent.get()

        data = ""
        for entry in dataBackup:
            data = data + entry[0] + "      " + entry[1] + "\n"
        e3.delete('1.0', END)
        e3.insert(INSERT, data)
but2=Button(window,text=" Check ",bg="lightpink",command=checkbutton,width=15,relief="solid",font=("arial",13,"bold"))
but2.place(x=170, y=470)

def clearbutton():
    e.delete(0,END)
    ent.delete(0,END)
    e3.delete('1.0', END)
but3=Button(window,text=" Clear ",command=clearbutton,bg="lightpink",width=15,relief="solid",font=("arial",13,"bold"))
but3.place(x=350, y=470)
window.mainloop()