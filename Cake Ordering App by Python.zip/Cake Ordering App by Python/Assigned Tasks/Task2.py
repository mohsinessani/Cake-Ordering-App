import mysql.connector
from tkinter import *
from tkinter import messagebox

w = Tk()
w.title("Registration Form")
w.geometry("410x400")

lblHeading = Label(w, text="Registration Form")
lblHeading.place(x=150,y=50)

# Name
lbl_Name = Label(w, text="Name")
lbl_Name.place(x=100,y=100)
ent_Name = Entry(w)
ent_Name.place(x=200, y=100)

# Number
lbl_Number = Label(w, text="Number")
lbl_Number.place(x=100,y=130)
ent_Number = Entry(w)
ent_Number.place(x=200, y=130)

# Email
lbl_Email = Label(w, text="Email")
lbl_Email.place(x=100,y=160)
ent_Email = Entry(w)
ent_Email.place(x=200, y=160)

# Address
lbl_Address = Label(w, text="Address")
lbl_Address.place(x=100,y=190)
ent_Address = Entry(w)
ent_Address.place(x=200, y=190)

# Password
lbl_Password = Label(w, text="Password")
lbl_Password.place(x=100,y=220)
ent_Password = Entry(w, show="*")
ent_Password.place(x=200, y=220)

def submitData():
    # Get All Data
    name = ent_Name.get()
    number = ent_Number.get()
    email = ent_Email.get()
    address = ent_Address.get()
    password = ent_Password.get()

    mydb = mysql.connector.connect(host="localhost", user="root", passwd="", database="mohsin_ceo")
    myCursor = mydb.cursor()

    sql = "SELECT * FROM `employee` WHERE `name`='" + name + "' OR `number`='" + number + "' OR `email`='" + email + "' OR `address`='" + address + "' OR `password`='" + password + "'"
    myCursor.execute(sql)

    results = myCursor.fetchall()

    # General Validations
    error=0
    if len(results)>0:
        error = 1
        messagebox.showerror("Data Exists", "Inserted Data Already Exists")
    elif len(name)==0:
        error = 1
        messagebox.showerror("Empty Name", "Please enter name field")
    elif len(str(number))!=10 or not str(number).isnumeric():
        error=1
        messagebox.showerror("Invalid Number","Please enter valid 10 digit mobile number")
    elif len(email)<3 or str(email).index("@")<0:
        error=1
        messagebox.showerror("Invalid Email","Please enter valid email address")
    elif len(address)<3 or str(email).index("@")<0:
        error=1
        messagebox.showerror("Invalid Email","Please enter valid email address")
    elif len(password)<5 or str(password).isalnum():
        error=1
        messagebox.showerror("Invalid Password","Password should contain atleast one special character and should contain minimum 5 digit")

    if error==0:
        sql = "INSERT INTO `employee`( `name`, `number`, `email`, `address`, `password`) VALUES ('"+name+"',"+number+",'"+email+"','"+address+"','"+password+"')"
        myCursor.execute(sql)
        mydb.commit()
        messagebox.showinfo("Data Inserted!", "Data Inserted Successfully!")

        ent_Name.delete(0, 'end')
        ent_Number.delete(0, 'end')
        ent_Email.delete(0, 'end')
        ent_Address.delete(0, 'end')
        ent_Password.delete(0, 'end')

# Submit Button
btn_submit = Button(w, text="SUBMIT", width=10, height=2, command=submitData)
btn_submit.place(x=150,y=270)
w.mainloop()