                                        # Import Tkinter

from tkinter import *

window = Tk()  # Assigning Tk variable
window.geometry("500x500")  # Window Size
window.title("Registration Form") #Window Title

                                        # Label 1  Reg Form

label1 = Label(window, text="Registration Form", fg="blue", bg="yellow", relief="solid", width=20,
               font=("arial", 19, "bold"))
label1.place(x=90, y=53)


                                        # Textbox for Label2

e = Entry(window, width=20, font=("arial", 17, "italic"))
e.grid(row=1, column=1)


                                        # Label 2 Reg Form

label2 = Label(window, text="Enter Your Name", fg="blue", relief="solid", width=15, font=("arial", 17, "italic"))
label2.place(x=20, y=120)
e.place(x=250, y=130)

                                        #Insert Data

def insert_data():
    print("Data has been inserted")
    data = e.get()
    print(data)

b1 = Button(window, text="Insert Data", command=insert_data, bg="light pink", relief="solid", width=12, font=("arial", 16))
b1.place(x=120, y=180)


                                        #Fetch Data of user

def fetch_data():
    print("Fetched Data")
    data = e.get()
    label3 = Label(window, text=data, fg="blue", relief="solid", width=15, font=("arial", 17, "italic"))
    label3.place(x=90, y=320)
    print(data)


b2 = Button(window, text="Fetch Data", bg="light pink", command=fetch_data, relief="solid", width=12,
            font=("arial", 16))
b2.place(x=120, y=250)


label3 = Label(window, text=" ", fg="blue", relief="solid", width=15, font=("arial", 17, "italic"))
label3.place(x=90, y=320)

                                        #Encrypt Data

def encrypt_data():
    data = e.get()
    if e['show']=="*": e['show'] = ""  #Decrypt(if textbox has patern * then convert it into plaintext)

    else: e['show']="*"  #Encrypt(If textbox has string then convert it into pattern *)

    if b3['text'] == "Decrypt Data": b3['text'] = "Encrypt Data" #(First click on Decrypt data automatically switch to Encrypt Data)
    else: b3['text'] = "Decrypt Data"#(decypt Data will be by default)


b3 = Button(window, text="Encrypt Data",  bg="light pink", command=encrypt_data, relief="solid", width=12, font=("arial", 16))
b3.place(x=120, y=380)


                                        #Enable/Disable Data

dataMain = ""    # Glboal variable to store

def enable_data():
    global dataMain
    if e.get()!="": #Fetch data from textbox if the data is not blank then pass the data to global variable i.e dataMain
        dataMain = e.get()
        e.delete(0, END)  # (Data will be deleted or hidden from textbox 0 indicates the index position of character and END indicates the end of character)
    else:
        e.insert(0, dataMain) #(Data will be enabled User can insert the data or can do any operations )

    if b4['text'] == "Enable": b4['text'] = "Disable" #(Has 2 buttons enable and disable First click on Enable and then automatically switch to Disbale)
    else: b4['text'] = "Enable" #(By Default it will be enable)

b4 = Button(window, text="Disable", bg="light pink", command=enable_data, relief="solid", width=12, font=("arial", 16))
b4.place(x=120, y=445)


                                        #Read only Data

def readOnly():
    e.config(state=DISABLED) #state=Disabled means the data has not the privilege or access to write)
b5 = Button(window, text="Read Only", bg="light pink", command=readOnly, relief="solid", width=12, font=("arial", 16))
b5.place(x=120, y=510)


                                        #Edit Data

def editOnly():
    e.config(state=NORMAL) #state =Normal means you can do the editing of the data
b6 = Button(window, text="Edit", bg="light pink", command=editOnly, relief="solid", width=12, font=("arial", 16))
b6.place(x=120, y=580)


                            #Note:All code must reside above window.mainloop()
window.mainloop()

































