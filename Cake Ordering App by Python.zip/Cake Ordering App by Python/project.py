
# Importing Tkinter and its Packages

from tkinter import *
import tkinter as tk
import mysql.connector



                # Creating Window Object
window=Tk()
window.geometry("700x950")
window.title("Essani's Delight")

                # Creating a Canvas and inserting background image
C = Canvas(window, height=2700, width=1700)
filename = PhotoImage(file = "C:\\Users\\DBLPC11\\Desktop\\background (2).png")
background_label = Label(window, image=filename)
background_label.place( x=00,y=0,relwidth=1,relheight=1)
C.pack()



                # Creating a Label Heading
lblhead=Label(window,text="Essani's Delight",fg="white",bg="brown",relief="solid",width="20",font=("algerian", 30))
lblhead.place(x=185,y=55)



                # Creating a Label of Username
lbluname=Label(window,text=" Consumer Name",fg="black",relief="solid",width="14",font=("", 17, "italic"))
lbluname.place(x=35,y=180)
                # Creating a Textbox for Username
txtboxuname = Entry(window, width=13, font=("arial", 17, "italic"))
txtboxuname.place(x=250,y=180)



                # Placing logo of the shop name
character=PhotoImage(file=r"C:\Users\DBLPC11\Desktop\character.png")
lblchar=Label(window,image=character)
lblchar.place(x=725,y=20)



                # Creating a Label of Mobile
lblumobile=Label(window,text="Consumer Number",fg="black",relief="solid",width="16",font=("", 17, "italic"))
lblumobile.place(x=460,y=180)
                # Creating a Textbox for Mobile
txtboxumobile = Entry(window, width=13, font=("arial", 17, "italic"))
txtboxumobile.place(x=705,y=180)




                # Defining a product in list
productName=["forest","vanilla","pineapple","donut","creamroll","blueberry1","dryfruit","water","colddrink"]
                # Defining a Price List
priceList = [500,60,75,60,75,90,130,20,50]
                # By Default the quantity is set to 0
quantityList = [0,0,0,0,0,0,0,0,0]


def increment(obj,index):
    global quantityList
    q = obj.get()
    obj.delete(0, END)
    if str(q).isnumeric():
        obj.insert(0, str(int(q) + 1))
    else:
        obj.insert(0, str(1))
    quantityList[index]+=1
    print(quantityList)

def itemPress(item):
    if item==0: increment(forest_ent,0)
    elif item==1: increment(vanilla_ent,1)
    elif item==2: increment(pineapple_ent,2)
    elif item==3: increment(donut_ent,3)
    elif item==4: increment(creamroll_ent,4)
    elif item==5: increment(blueberry1_ent,5)
    elif item==6: increment(dryfruit_ent,6)
    elif item==7: increment(water_ent,7)
    elif item==8: increment(colddrink_ent,8)

def totalItems():
    global quantityList
    entityList = [forest_ent,vanilla_ent,pineapple_ent,donut_ent,creamroll_ent,blueberry1_ent,dryfruit_ent,water_ent,colddrink_ent]
    for i in range(len(entityList)):
        q = entityList[i].get()
        if str(q).isnumeric():
            newVal = int(q)
            quantityList[i]=newVal
    sum=0
    for x in quantityList:
       sum+=x
    button2_ent.delete(0, END)
    button2_ent.insert(0, str(sum))

def totalPrice():
    global quantityList, priceList
    entityList = [forest_ent, vanilla_ent, pineapple_ent, donut_ent, creamroll_ent, blueberry1_ent, dryfruit_ent, water_ent,
                  colddrink_ent]
    for i in range(len(entityList)):
        q = entityList[i].get()
        if str(q).isnumeric():
            newVal = int(q)
            quantityList[i] = newVal
    sum=0
    for i in range(len(quantityList)):
        sum = sum + (quantityList[i]*priceList[i])
    button3_ent.delete(0, END)
    button3_ent.insert(0, str(sum))
   


                    # Creating Image Buttons and placing textbox for Image

forest=PhotoImage(file=r"C:\Users\DBLPC11\Desktop\forest.png")
forestbutton=Button(window,width=150,height=130,image=forest,command=lambda: itemPress(0))
forestbutton.place(x=50,y=275)                          #1
forest_ent=Entry(window,width=10,font=("arial",12))
forest_ent.place(x=230,y=310)

vanilla=PhotoImage(file=r"C:\Users\DBLPC11\Desktop\vanilla.png")
vanillabutton=Button(window,width=150,height=130,image=vanilla,command=lambda: itemPress(1))
vanillabutton.place(x=350,y=275)                       #2
vanilla_ent=Entry(window,width=10,font=("arial",12))
vanilla_ent.place(x=520,y=310)

pineapple=PhotoImage(file=r"C:\Users\DBLPC11\Desktop\pineapple.png")
pineapplebutton=Button(window,width=150,height=130,image=pineapple,command=lambda: itemPress(2))
pineapplebutton.place(x=630,y=275)                       #3
pineapple_ent=Entry(window,width=10,font=("arial",12))
pineapple_ent.place(x=800,y=310)

donut=PhotoImage(file=r"C:\Users\DBLPC11\Desktop\donut.png")
donutbutton=Button(window,width=150,height=130,image=donut,command=lambda: itemPress(3))
donutbutton.place(x=50,y=470)                   #4
donut_ent=Entry(window,width=10,font=("arial",12))
donut_ent.place(x=230,y=520)


creamroll=PhotoImage(file=r"C:\Users\DBLPC11\Desktop\creamroll.png")
creamrollbutton=Button(window,width=150,height=130,image=creamroll,command=lambda: itemPress(4))
creamrollbutton.place(x=350,y=470)                      #5
creamroll_ent=Entry(window,width=10,font=("arial",12))
creamroll_ent.place(x=520,y=520)

blueberry1=PhotoImage(file=r"C:\Users\DBLPC11\Desktop\blueberry1.png")
blueberry1button=Button(window,width=150,height=130,image=blueberry1,command=lambda: itemPress(5))
blueberry1button.place(x=630,y=470)                       #6
blueberry1_ent=Entry(window,width=10,font=("arial",12))
blueberry1_ent.place(x=800,y=530)

dryfruit=PhotoImage(file=r"C:\Users\DBLPC11\Desktop\dryfruit.png")
dryfruitbutton=Button(window,width=150,height=130,image=dryfruit,command=lambda: itemPress(6))
dryfruitbutton.place(x=50,y=665)                      #7
dryfruit_ent=Entry(window,width=10,font=("arial",12))
dryfruit_ent.place(x=230,y=720)

water=PhotoImage(file=r"C:\Users\DBLPC11\Desktop\water.png")
waterbutton=Button(window,width=150,height=130,image=water,command=lambda: itemPress(7))
waterbutton.place(x=350,y=665)                        #8
water_ent=Entry(window,width=10,font=("arial",12))
water_ent.place(x=520,y=720)

colddrink=PhotoImage(file=r"C:\Users\DBLPC11\Desktop\colddrink.png")
colddrinkbutton=Button(window,width=150,height=130,image=colddrink,command=lambda: itemPress(8))
colddrinkbutton.place(x=630,y=665)                       #9
colddrink_ent=Entry(window,width=10,font=("arial",12))
colddrink_ent.place(x=800,y=720)


                    # Creating 2 Buttons for Total Items and Total Price

button2=Button(window,text="Total Items",width="11",height="3",bg="red",command=totalItems)
button2.place(x=970,y=550)
button2_ent=Entry(window,width="9",font=("arial",22))
button2_ent.place(x=1075,y=550)

button3=Button(window,text="Total Price",width="11",height="3",bg="red",command=totalPrice)
button3.place(x=970,y=620)
button3_ent=Entry(window,width="9",font=("arial",22))
button3_ent.place(x=1075,y=620)



                    # Creating a Function Bill
                    # Establishing Database Connection
                    # Fetching id,name and mobile number from database


def bill():
    global priceList,quantityListList
    mydb = mysql.connector.connect(host="localhost", user="root", passwd="", database="essani_delight")
    myCursor = mydb.cursor()

    user = txtboxuname.get()
    mobile = txtboxumobile.get()
  

    # if user=="" or mobile=="" or not str(mobile).isnumeric() or len(str(mobile))!=10:
    #     messagebox.showerror("Incorrect data","Please enter all customer data")
    #     return

                        # Inserting Values into Customer

    sql = "INSERT INTO `customer`(`name`, `mobile`) VALUES ('" + user + "'," + mobile + ")"
    myCursor.execute(sql)
    mydb.commit()
    lastrowid = myCursor.lastrowid

                        # Fetching all records from database
    sql = "SELECT * FROM `customer` WHERE `id`=" + str(lastrowid)
    myCursor.execute(sql)
    record = myCursor.fetchall()

                        # Creating a Window Object
    w2=Tk()
    w2.geometry("1366x768")
    w2.title("Bill")

    
   

                        # Printing Order details of Customer i.e Customer id, Customer name and Customer Mobile No

    customer = "Customer ID: " + str(record[0][0]) + "                  Customer Name: " +  str(record[0][1]) + "                  Customer Mobile: " + str(record[0][2])+"                   Datetime:"+str(record[0][3])
    price = ""
    count = 1
    total = 0
    for i in range(len(quantityList)):
        if quantityList[i] > 0:
            total += priceList[i] * quantityList[i]
            price += str(count) + "                  " + productName[i] + "                  " + str(priceList[i]) + "*" + str(quantityList[i]) + "                  " + str(priceList[i]*quantityList[i]) + "\n"
            count+=1

    price += "                             Total                                         " + str(total) + "\n"

    CustomerLabel = Label(w2, text=customer, width=100, bg="#C0C0C0", fg="red", relief="solid", font=("arial", 12, "bold"))
    CustomerLabel.place(x=10, y=10)

    PriceLabel = Label(w2, text=price, font=("arial", 12, "bold"))
    PriceLabel.place(x=10, y=50)

    w2.mainloop()


billbutton=Button(window,text="Bill",width=15,bg="#C0C0C0",fg="red",relief="solid",font=("arial",12,"bold"),command=bill)
billbutton.place(x=1025,y=700)






#calculator
textin = StringVar()
operator = ""


def clickbut(number):  # lambda:clickbut(1)
    global operator
    operator = operator + str(number)
    textin.set(operator)


def equlbut():
    global operator
    add = str(eval(operator))
    textin.set(add)
    operator = ''


def equlbut():
    global operator
    sub = str(eval(operator))
    textin.set(sub)
    operator = ''


def equlbut():
    global operator
    mul = str(eval(operator))
    textin.set(mul)
    operator = ''


def equlbut():
    global operator
    div = str(eval(operator))
    textin.set(div)
    operator = ''


def clrbut():
    textin.set('')


#buttons

text = Entry(window, font=("Courier New", 12, 'bold'), textvar=textin, width=34, bd=5, bg='powder blue')
text.place(x=950,y=95)

but1 = Button(window, padx=14, pady=14, bd=4, bg='white', command=lambda: clickbut(1), text="1",font=("Courier New", 16, 'bold'))
but1.place(x=950, y=140)

but2 = Button(window, padx=14, pady=14, bd=4, bg='white', command=lambda: clickbut(2), text="2",font=("Courier New", 16, 'bold'))
but2.place(x=1020, y=140)

but3 = Button(window, padx=14, pady=14, bd=4, bg='white', command=lambda: clickbut(3), text="3",font=("Courier New", 16, 'bold'))
but3.place(x=1090, y=140)

but4 = Button(window, padx=14, pady=14, bd=4, bg='white', command=lambda: clickbut(4), text="4",font=("Courier New", 16, 'bold'))
but4.place(x=950, y=210)

but5 = Button(window, padx=14, pady=14, bd=4, bg='white', command=lambda: clickbut(5), text="5",font=("Courier New", 16, 'bold'))
but5.place(x=1020, y=210)

but6 = Button(window, padx=14, pady=14, bd=4, bg='white', command=lambda: clickbut(6), text="6",font=("Courier New", 16, 'bold'))
but6.place(x=1090, y=210)

but7 = Button(window, padx=14, pady=14, bd=4, bg='white', command=lambda: clickbut(7), text="7",font=("Courier New", 16, 'bold'))
but7.place(x=950, y=280)

but8 = Button(window, padx=14, pady=14, bd=4, bg='white', command=lambda: clickbut(8), text="8",font=("Courier New", 16, 'bold'))
but8.place(x=1020, y=280)

but9 = Button(window, padx=14, pady=14, bd=4, bg='white', command=lambda: clickbut(9), text="9",
              font=("Courier New", 16, 'bold'))
but9.place(x=1090, y=280)

but0 = Button(window, padx=14, pady=14, bd=4, bg='white', command=lambda: clickbut(0), text="0",font=("Courier New", 16, 'bold'))
but0.place(x=950, y=350)

butdot = Button(window, padx=49, pady=14, bd=4, bg='white', command=lambda: clickbut("."), text=".",font=("Courier New", 16, 'bold'))
butdot.place(x=1020, y=350)

butdiv = Button(window, padx=14, pady=14, bd=4, bg='white', text="/", command=lambda: clickbut("/"),font=("Courier New", 16, 'bold'))
butdiv.place(x=1160, y=350)

butpl = Button(window, padx=14, pady=14, bd=4, bg='white', text="+", command=lambda: clickbut("+"),font=("Courier New", 16, 'bold'))
butpl.place(x=1160, y=140)

butsub = Button(window, padx=14, pady=14, bd=4, bg='white', text="-", command=lambda: clickbut("-"),font=("Courier New", 16, 'bold'))
butsub.place(x=1160, y=210)

butml = Button(window, padx=14, pady=14, bd=4, bg='white', text="*", command=lambda: clickbut("*"),font=("Courier New", 16, 'bold'))
butml.place(x=1160, y=280)

butclear = Button(window, padx=12, pady=119, bd=4, bg='white', text="CE", command=clrbut, font=("Courier New", 16, 'bold'))
butclear.place(x=1230, y=140)

butequal = Button(window, padx=160, pady=14, bd=4, bg='white', command=equlbut, text="=", font=("Courier New", 16, 'bold'))
butequal.place(x=950, y=425)
window.mainloop()




